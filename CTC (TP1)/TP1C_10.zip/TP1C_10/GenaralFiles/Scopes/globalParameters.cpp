#include "../Header/globalParameters.h"

double aspectRatio = 0;
int keys[6] = {0,0,0,0,0,0};
//GLuint aviaoDisplayList, aviaoDisplayList1, aviaoDisplayList2, shotDisplayList, buttonDisplayList, drawEmphassisButtonDisplayList;
int sposition = -30;
int flag =1;
int tempo=0;
int cont = 0;

//auxAux = reinterpret_cast<MovableEntity*> (&auxEnt)