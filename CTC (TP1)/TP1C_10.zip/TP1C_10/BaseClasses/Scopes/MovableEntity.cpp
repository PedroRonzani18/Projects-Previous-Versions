#include "../Header/MovableEntity.h"

MovableEntity::MovableEntity() : Entity()
{}

void MovableEntity::move(){}
void MovableEntity::angularMove(){}
void MovableEntity::scaleMove(const double& scale){}