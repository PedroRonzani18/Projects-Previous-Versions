#ifndef _ORDEREDPAIR_H
#define _ORDEREDPAIR_H

class OrderedPair{
    private:
        double x;
        double y;

    public:
        double getX();
        void setX(double x);

        double getY();
        void setY(double y);

        void* getEnd();
};

#endif