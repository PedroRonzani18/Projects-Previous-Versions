#include "../Header/Stage.h"

Stage::Stage()
{
}

Stage::Stage(const int& background)
{
    this->setBackground(background);
}