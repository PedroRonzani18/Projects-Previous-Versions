#include "../Header/Level.h"

//Level::Level(){}

//Level::Level(const int& background) : Stage(background){}