#include "../Header/globalParameters.h"

double aspectRatio = 0;
int keys[6] = {0,0,0,0,0,0};
GLuint aviaoDisplayList, aviaoDisplayList1, aviaoDisplayList2, shotDisplayList, buttonDisplayList;
int sposition = -30;
int flag =1;
int tempo=0;