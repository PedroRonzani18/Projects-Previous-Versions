#include "../Header/OrderedPair.h"

#include <stdio.h>

OrderedPair::OrderedPair()
{}