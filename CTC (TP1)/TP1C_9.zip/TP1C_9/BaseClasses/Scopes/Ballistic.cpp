#include "../Header/Ballistic.h"
#include <stdio.h>

Ballistic::Ballistic(){}