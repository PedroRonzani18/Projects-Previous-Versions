#ifndef _DRAWINGS_H
#define _DRAWINGS_H

void desenhaPlayer();
void drawPlane1();
void drawPlane2();
void drawShot();

void drawMenuButton();

void drawBackground();

void drawEmphassisMenuButton();

void selec();

//void inicializaDisplayLists();


#endif