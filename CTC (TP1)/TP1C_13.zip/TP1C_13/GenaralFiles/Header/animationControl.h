#ifndef _ANIMATIONCONTROL_H
#define _ANIMATIONCONTROL_H

void intro();
void stageKeyboard();
void transition();

#endif