#ifndef _MENU_H
#define _MENU_H

#include "Stage.h"
#include "../../GenaralFiles/Header/globalParameters.h"
#include "../../BaseClasses/Header/Button.h"

class Menu: public Stage {

    private:
        

    public:
        Menu();

        Menu(const int& background);

        
};



#endif