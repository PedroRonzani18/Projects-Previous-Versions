#include "../Header/Ajuda.h"

Ajuda::Ajuda()
{
}

//Ajuda::Ajuda(const int& background) : stage(background){}