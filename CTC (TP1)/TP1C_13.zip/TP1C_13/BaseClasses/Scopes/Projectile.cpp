#include "../Header/Projectile.h"

Projectile::Projectile() : MovableEntity()
{}
