#include "../Header/Enemy.h"
#include <stdio.h>

Enemy::Enemy() : MovableEntity()
{}
