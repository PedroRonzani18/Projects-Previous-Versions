#include "../Header/Colectible.h"

Colectible::Colectible() : MovableEntity()
{}
