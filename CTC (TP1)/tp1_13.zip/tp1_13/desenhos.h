#ifndef _DESENHOS_H
#define _DESENHOS_H

void desenhaPlayer();
void drawPlane1();
void drawPlane2();
void drawShot();

#endif