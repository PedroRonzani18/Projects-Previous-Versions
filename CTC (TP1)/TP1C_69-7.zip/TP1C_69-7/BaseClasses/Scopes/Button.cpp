#include "../Header/Button.h"

Button::Button():Entity(){}
