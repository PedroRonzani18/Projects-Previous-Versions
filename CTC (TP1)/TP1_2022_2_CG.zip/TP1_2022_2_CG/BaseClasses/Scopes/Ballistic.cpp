#include "../Header/Ballistic.h"

Ballistic::Ballistic()
{}

