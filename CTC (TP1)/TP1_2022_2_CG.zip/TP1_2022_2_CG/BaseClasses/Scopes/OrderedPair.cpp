#include "../Header/OrderedPair.h"

OrderedPair::OrderedPair()
{}