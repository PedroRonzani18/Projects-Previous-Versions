#include "../Header/globalParameters.h"

int keys[6] = {0,0,0,0,0,0};
int auxKeys[3] = {0, 0, 0};
int tempo=0;
int cont = 0;
int top = 100, bottom = -100, left = -90, right = 90;
int frames = 16;
int bossTime = 0;