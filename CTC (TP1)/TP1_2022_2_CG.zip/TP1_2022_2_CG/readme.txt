Participantes do Trabalho Pratico 1:

Pedro Augusto de Portilho Ronzani - 20223002863
Ulisses Andrade Carvalho - 20223003341
Caio Palhares Rocha Porto - 20223006156
Letícia De Oliveira Soares - 20223002498
Augusto Coelho Fagundes - 20223002193
Matheus Monteiro Huebra Perdigão - 20223002738

Para compilar e executar o projeto, basta digitar "make run" no terminal.
Não foi utilizado nenhuma biblioteca adicional.

Para jogar siga os seguintes comandos:
    W: move para cima;
    A: move para a esquerda;
    S: move para baixo;
    D: move para a direita;
    spaço: atira e clica nos botões;
    esc: fechar o jogo.
    
A cada morte de um inimigo, existe uma chance de este ser substituido por um coletável que connceberá ao jogador um "upgrade":
    1. aumento de dano;
    2. aumento de taxa de disparos;
    3. troca de modelo de tiro;
    4. aumento da quantidade de tiros que são disparados por vez (1,2,3);
    5. aumento da vida.

O jogo acaba quando o jogador perde suas 4 vidas.