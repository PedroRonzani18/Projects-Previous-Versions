#ifndef _ANIMATIONCONTROL_H
#define _ANIMATIONCONTROL_H

void intro();
void transition();

#endif