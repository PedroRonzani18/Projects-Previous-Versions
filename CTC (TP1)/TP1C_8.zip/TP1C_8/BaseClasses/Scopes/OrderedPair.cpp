#include "../Header/OrderedPair.h"

#include <stdio.h>

OrderedPair::OrderedPair(){
    this->x = NULL;
    this->y = NULL;
}