#include "../Header/globalParameters.h"

int keys[6] = {0,0,0,0,0,0};
int sposition = -30;
int flag =1;
int tempo=0;
int cont = 0;
int top = 100, bottom = -100, left = -90, right = 90;

std::vector<GLuint> textures;



//auxAux = reinterpret_cast<MovableEntity*> (&auxEnt)