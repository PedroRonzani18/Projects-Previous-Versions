#include "../Header/animationControl.h"

void intro(){}
void transition(){}