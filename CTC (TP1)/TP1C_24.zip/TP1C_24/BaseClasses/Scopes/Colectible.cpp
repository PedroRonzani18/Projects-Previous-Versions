#include "../Header/Colectible.h"

Colectible::Colectible() : MovableEntity()
{}

void Colectible::move(){}
void Colectible::scaleMove(const double& scale){}