#include "../Header/globalParameters.h"

int keys[6] = {0,0,0,0,0,0};
int sposition = -30;
int tempo=0;
int cont = 0;
int top = 100, bottom = -100, left = -90, right = 90;
int frames = 16;

//auxAux = reinterpret_cast<MovableEntity*> (&auxEnt)